"""Static Values for Testing"""
