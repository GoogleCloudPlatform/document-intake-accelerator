"""
Flatten import namespace for models
"""

from .base_model import *
from .claim import *
from .document import *
